<template>
  <div class='music-list'>
    <div class='top'>
      <div class='title'>推荐歌单</div>
      <div class='more'>更多 &gt;</div>
    </div>
    <div class='list'>
      <div class='content'>
        <div>
          <img src='../../../assets/image/img1.jpg' alt=''>
          <div class='text'>美女都爱听的歌儿哟</div>
        </div>
        <div>
          <img src='../../../assets/image/img2.jpg' alt=''>
          <div class='text'>今天从《打上花火》听起|私人雷达哈哈哈哈哈哈哈哈</div>
        </div>
        <div>
          <img src='../../../assets/image/img3.jpg' alt=''>
          <div class='text'>甜酷女孩专用歌单</div>
        </div>
        <div>
          <img src='../../../assets/image/img4.jpg' alt=''>
          <div class='text'>好听到单曲循环哦~</div>
        </div>
        <div>
          <img src='../../../assets/image/img5.jpg' alt=''>
          <div class='text'>2022全网保活流行歌曲推荐按</div>
        </div>
        <div>
          <img src='../../../assets/image/img6.jpg' alt=''>
          <div class='text'>沉浸在惬意学习时光里</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue'

export default defineComponent({
  components:{
  },
  setup() {
    return {}
  }
})
</script>

<style scoped lang='less'>
  .music-list{
    padding: -1px 10px;
    border-top: 2px solid rgb(243,243,241);

  .top{
    display: flex;
    justify-content: space-between;
    margin-top: 2px;
    .title{
      font-size: 16px;
      font-weight: 900;
    }
    .more{
      border: 1px solid #666666;
      padding: 1px;
      border-radius: 12px;
      width: 55px;
      text-align: center;
    }
  }
  ::-webkit-scrollbar {
    /*隐藏滚轮*/
    display: none;
  }
  .content{
      display: flex;
      flex-direction: row;
      margin-top: 10px;
      width: 100%;
      overflow-x: scroll;
      overflow-y: hidden;

      span{
        color: #666666;
        text-align: center;
      }
      div{
        height: 145px;
        color: #fff;
        margin-right:11px;
      }

      .text{
        color: #666666;
        text-align: center;
        width: 92px;
        height: 43px;
        overflow: hidden;
      }
      img{
        width: 95px;
        height: 90px;
        border-radius: 8px;
        box-shadow: 0 2px 7px #666;
      }
    }
  }
</style>
