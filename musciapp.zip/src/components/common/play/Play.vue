<template>
  <div class='play'>
    <div class='play-left'>
      <img src='../../../assets/image/img1.jpg' alt=''>
      <span>鼓楼</span>
    </div>
    <div class='play-right'>
      <div class='iconfont icon-bofang'></div>
      <div class='iconfont icon-liebiao1'></div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue'

export default defineComponent({
  setup() {
    return {}
  }
})
</script>

<style scoped lang='less'>
.play{
  width: 100%;
  height: 56px;
  line-height: 56px;
  position: fixed;
  bottom: 48px;
  display: flex;
  justify-content: space-between;
  padding: 0 8px;
  background-color: #ffffff;
  img{
    font-size: 15px;
    width: 50px;
    height: 50px;
    border: 7px solid black;
    border-radius: 50%;
    margin-top: -4px;
  }
  .play-right{
    display: flex;
    .iconfont{
      margin-left: 20px;
      font-size: 35px;
    }
  }
  .play-left{
    span{
      padding:0 10px;
      font-size: 17px;
    }
  }
}
</style>
