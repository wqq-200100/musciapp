<template>
    <div class='banner'>
      <a-carousel autoplay >
        <img src='../../../assets/image/image.jpg'>
        <img src='../../../assets/image/image.jpg'>
        <img src='../../../assets/image/image.jpg'>
      </a-carousel>
    </div>
</template>

<script>
import { defineComponent } from 'vue'
import { Carousel} from 'ant-design-vue'

export default defineComponent({
  components:{
    Carousel
  },
  setup() {

    return {
    }
  }
})
</script>

<style scoped lang='less'>
.banner{
  margin-top: 2px;
  width: 100%;
}
.ant-carousel :deep(.slick-slide) {
  text-align: center;
  height: 150px;
  line-height: 150px;
  background: #364d79;
  overflow: hidden;
  border-radius: 15px;
}
</style>
