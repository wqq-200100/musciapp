<template>
  <router-view/>
</template>

<script>
import { defineComponent } from 'vue'
// import tabControl from './components/content/tabControl/TabControl.vue'
// import Play from './components/common/play/Play'

export default defineComponent({
  setup() {
    return {}
  }
})
</script>

<style scoped lang='less'>
@import "assets/css/base.css";
</style>
