<template>
  <div class='music'>
    <MusicTitle>
      <template #left>
        <div class='iconfont icon-shuaxin'></div>
        <span>二次元赛高</span>
      </template>
      <template #right>
        <div class='iconfont icon-sanjiaoxing'></div>
        <span>播放</span>
      </template>
    </MusicTitle>

    <div class='box'>
        <div class='box-top'>
          <div class='left'>
            <img src='../../../assets/image/img6.jpg' alt=''>
            <div class='title'>鼓楼 <span>-赵雷</span></div>
            <div class='iconfont icon-sanjiaoxing'></div>
          </div>
          <div class='right'>
            <img src='../../../assets/image/img5.jpg' alt=''>
            <div class='title'>女儿国 <span>-张靓颖/李荣浩</span></div>
            <div class='iconfont icon-sanjiaoxing'></div>
          </div>
        </div>
        <div class='box-bottom'>
          <div class='left'>
            <img src='../../../assets/image/img4.jpg' alt=''>
            <div class='title'>画 <span>-赵雷</span></div>
            <div class='iconfont icon-sanjiaoxing'></div>
          </div>
          <div class='right'>
            <img src='../../../assets/image/img6.jpg' alt=''>
            <div class='title'>如约而至 <span>-许嵩</span></div>
            <div class='iconfont icon-sanjiaoxing'></div>
          </div>
        </div>
      </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue'
import MusicTitle from '../../../components/content/musictitle/MusicTitle'

export default defineComponent({
  components:{
    MusicTitle
  },
  setup() {
    return {}
  }
})
</script>

<style scoped lang='less'>
.music{
  width: 100%;
  height: 120px;
  .top-left span{
    font-size: 20px;
    font-weight: 750;
  }
  .top-left .iconfont{
    font-size: 20px;
    margin-right: 7px;
  }
  ::-webkit-scrollbar {
    /*隐藏滚轮*/
    display: none;
  }
  .box{
    flex-direction: row;
    overflow-x: scroll;
    overflow-y: scroll;
    display: flex;
    height: 230px;
    img{
      width: 55px;
      height:55px;
      border-radius: 10px;
    }
    .right{
      border-top: 2px solid #f3f3f1;
      padding-top: 4px;
    }
    .left,.right{
      width: 403px;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      margin:1px 7px;
      .iconfont{
        width: 28px;
        padding: 0 5px;
        border: 1px solid #666666;
        border-radius: 10px;
        height: 27px;
        color: #666;
        margin-left: auto;
      }
      .title{
        line-height: 55px;
        font-size: 17px;
        font-weight: 500;
        margin-left: 15px;
        span{
          font-size: 14px;
          color:#888 ;
        }
      }
    }
  }
}
</style>
