<template>
  <IconfontList>
    <div class='icon-list'>
      <div class='list-item'>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-fanjutuijian"></use>
        </svg>
        <span>每日推荐</span>
      </div>
    </div>
    <div class='icon-list'>
      <div class='list-item'>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-paihangbang"></use>
        </svg>
        <span>私人FM</span>
      </div>
    </div>
    <div class='icon-list'>
      <div class='list-item'>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-paihang"></use>
        </svg>
        <span>排行榜</span>
      </div>
    </div>
    <div class='icon-list'>
      <div class='list-item'>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-airec"></use>
        </svg>
        <span>直播</span>
      </div>
    </div>
    <div class='icon-list'>
      <div class='list-item'>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-right"></use>
        </svg>
        <span>超级喜欢</span>
      </div>
    </div>
    <div class='icon-list'>
      <div class='list-item'>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-sirendingzhi"></use>
        </svg>
        <span>巴卡马卡</span>
      </div>
    </div>
    <div class='icon-list'>
      <div class='list-item'>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-airec"></use>
        </svg>
        <span>快乐加倍</span>
      </div>
    </div>
  </IconfontList>
</template>
<script>
import { defineComponent } from 'vue'
import IconfontList from '../../../components/common/iconfontList/IconfontList'

export default defineComponent({
  components:{
    IconfontList
  },
  setup() {
    return {}
  }
})
</script>

<style scoped lang='less'>
.list-item{
    width: 74px;
    height: 66px;
    text-align: center;
    margin: 0 5px;
    span{
      font-size: 12px;
    }
    .icon{
      width: 41px;
      height: 41px;
      text-align: center;
      display: block;
      margin: 0 auto;
    }
  }
</style>
