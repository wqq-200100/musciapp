import axios from 'axios'

// 配置默认的host
axios.defaults.baseURL = 'http://localhost:8080/Login'
// 添加请求拦截
axios.interceptors.request.use((config) =>{
  // 再发送请求之前做什么
  console.log('请求成功的拦截')
  const token = ''
  config.headers.Authorization = `Bearer ${token}`
  return config
},(err) =>{
  // 对请求错误做什么
  console.log('请求失败的拦截')
  switch (err.response.status){
    case 404:
      console.log('NouFount')
  }
  return err
});

// 添加响应拦截器
axios.interceptors.response.use((response) => {
    console.log('响应成功的拦截')
    return response
  },
  (err) => {
    console.log('响应失败的拦截')
    return Promise.reject(err)
  })

