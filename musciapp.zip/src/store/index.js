import { createStore } from 'vuex'

export default createStore({
  state: () => {
    return {
      name:'大清'
    }
  },
  mutations: {},
  actions: {},
  modules: {}
})
